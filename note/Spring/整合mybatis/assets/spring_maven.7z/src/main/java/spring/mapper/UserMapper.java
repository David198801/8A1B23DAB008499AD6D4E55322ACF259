package spring.mapper;

import spring.bean.User;
import org.apache.ibatis.annotations.MapKey;

import java.util.List;
import java.util.Map;

public interface UserMapper {

    public List<User> getAllUser();

    public User getUserById(Integer id);

    public Map<String,Object> getUserByIdReturnMap(Integer id);

    @MapKey("id")
    public Map<Integer,User> getAllUserMap();

    public void addUser(User user);

    public void updateUser(User user);

    public void deleteUserById(Integer id);
}
