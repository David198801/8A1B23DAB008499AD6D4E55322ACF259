package spring.utils;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

public class MybatisUtils {

    private static MybatisUtils mybatisUtils;

    private SqlSessionFactory sqlSessionFactory;

    private MybatisUtils(){
        SqlSessionFactoryBuilder sqlSessionFactoryBuilder = new SqlSessionFactoryBuilder();
        try {
            InputStream is = Resources.getResourceAsStream("mybatis-config.xml");
            sqlSessionFactory = sqlSessionFactoryBuilder.build(is);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static MybatisUtils getInstance(){
        if(null==mybatisUtils){
            synchronized (MybatisUtils.class){
                if (null==mybatisUtils){
                    mybatisUtils = new MybatisUtils();
                }
            }
        }
        return mybatisUtils;
    }

    public SqlSession getSqlSession(){
        return sqlSessionFactory.openSession(true);
    }
}
