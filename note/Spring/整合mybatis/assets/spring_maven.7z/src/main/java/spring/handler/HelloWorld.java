package spring.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import spring.bean.Book;
import spring.bean.User;

import java.util.Map;

@Controller
public class HelloWorld {

    // @Autowired
    // private Book book;

    /**
     * 使用 @RequestMapping 映射请求的 URL
     * @return 返回值会通过视图解析器解析为实际的物理视图
     */
    @RequestMapping("/")
    public String hello(){
        return "helloworld";
    }
    // @RequestMapping("/helloworld")
    // public String hello(Map<String,Object> map){
    //     map.put("book",book);
    //     return "helloworld";
    // }
}
