package spring.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import spring.bean.User;
import spring.service.UserService;

import java.util.List;
import java.util.Map;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/users")
    public String users(Map<String,Object> map){
        List<User> users = userService.getAllUsers();
        map.put("users", users);
        return "users";
    }

    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }
}
