package spring.mapper;

import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import spring.bean.User;
import spring.utils.MybatisUtils;

import java.util.List;

import static org.junit.Assert.*;

public class UserMapperTest {

    @Test
    public void getAllUser() {
        SqlSession sqlSession = MybatisUtils.getInstance().getSqlSession();
        try {
            UserMapper mapper = sqlSession.getMapper(UserMapper.class);
            List<User> allUser = mapper.getAllUser();
            for (User user : allUser) {
                System.out.println(user);
            }
        }finally {
            sqlSession.close();
        }
    }
}