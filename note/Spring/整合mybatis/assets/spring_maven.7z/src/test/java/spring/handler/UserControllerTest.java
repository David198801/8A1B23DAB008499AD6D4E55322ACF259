package spring.handler;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.Assert.*;

public class UserControllerTest {

    @Test
    public void test(){
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring.xml");
        ApplicationContext applicationContext2 = new ClassPathXmlApplicationContext("DispacherServlet-servlet.xml");
        UserController userController = (UserController)applicationContext.getBean("userController", UserController.class);
        System.out.println(userController.getAllUsers());
    }

}