package com.example.springbootsqlite.controller;

import com.example.springbootsqlite.service.UserService;
import com.example.springbootsqlite.vo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    UserService userService;

    @ResponseBody
    @RequestMapping("/getUserNameById")
    public String getUserNameById(String id){
        return userService.getUserNameById(id);
    }

    @ResponseBody
    @RequestMapping("/getUserById")
    public User getUserById(String id){
        return userService.getUserById(id);
    }

}
