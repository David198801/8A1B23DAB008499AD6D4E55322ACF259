package com.example.springbootsqlite.service;

import com.example.springbootsqlite.mapper.UserMapper;
import com.example.springbootsqlite.vo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public User getUserById(String id){
        return userMapper.getUserById(id);
    }

    public String getUserNameById(String id){
        User user = userMapper.getUserById(id);
        return user==null?null:user.getName();
    }
}
