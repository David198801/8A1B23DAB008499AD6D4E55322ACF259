package com.example.springbootsqlite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootSqliteApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootSqliteApplication.class, args);
    }

}
