package student;

public class Test {

	public static void main(String[] args) {
		StudentService ss = new StudentService();
		ss.addStudent("aa","Ů",Integer.parseInt("15"),"aaa","aaa");
	}
}
