package ordersystem;

public class Dish extends Food{

	
	private String type;//����
	
	//���췽��
	public Dish() {}
	public Dish(int id, String name, double price,String type) {
		super(id, name, price);
		this.type=type;
	}

	//get set ����
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	
}
