package ordersystem;

public class Drink extends Food{

	private String taste;//��ζ
	
	//���췽��
	public Drink(){}
	public Drink(int id, String name, double price,String taste) {
		super(id, name, price);
		this.taste=taste;
	}
	
	//get set ����
	public String getTaste() {
		return taste;
	}
	public void setTaste(String taste) {
		this.taste = taste;
	}
}
