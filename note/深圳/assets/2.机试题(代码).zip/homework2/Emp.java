package homework2;

public class Emp {
	//����
	private int eno;
	private String ename;
	private String esex;
	
	//��дequals��������eno��ename��ͬʱ��ʵ�ֱȽ�2�������
	@Override
	public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o instanceof Emp) {
        	Emp e = (Emp) o;
            if(e.getEno() == this.eno && e.getEname()==this.ename){
            	return true;
            }
        }
        return false;
    }
	
	//������
	public Emp() {
	}
	public Emp(int eno, String ename, String esex) {
		this.eno = eno;
		this.ename = ename;
		this.esex = esex;
	}
	
	//get set����
	public int getEno() {
		return eno;
	}

	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getEsex() {
		return esex;
	}
	public void setEsex(String esex) {
		this.esex = esex;
	}
}
