package h3;

public class Test {

	public static void main(String[] args) {
		Voter voter = new Voter();
		//100���߳�ͶƱ
		for (int i = 1; i <= 100; i++) {
			new Thread(voter,"�û�"+i+"��").start();
		}
	}
}
