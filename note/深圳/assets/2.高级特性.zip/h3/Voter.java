package h3;

public class Voter implements Runnable{
	//ͶƱ��
	public int box=0;

	@Override
	public synchronized void run() {
		box += 1;
		System.out.println(Thread.currentThread().getName()+"Ͷ��1Ʊ����ǰƱ��"+box);
	}

}
