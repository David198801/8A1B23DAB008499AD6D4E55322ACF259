package h4;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ReadXML {

	public static void main(String[] args) {
		//��ȡ������ʵ��
		DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();

		
			//��ȡDocumentBuilder
			DocumentBuilder builder;
			try {
				builder = f.newDocumentBuilder();
				//����xml
				File file = new File("src\\h4\\NewFile.xml");
				Document document = builder.parse(file);
				//��ȡstudent�ڵ�
				NodeList students = document.getElementsByTagName("student");
				for (int i = 0; i < students.getLength(); i++) {
					Node studentNode = students.item(i);
					Element studentElement = (Element)studentNode;
					//���student��id��name����
					System.out.print(
							"ѧ�ţ�" + studentElement.getAttribute("id") + "\t" +
							"������" + studentElement.getAttribute("name") + "\t"
					);
					
					//��ȡproperty�ڵ�
					NodeList properties = studentElement.getElementsByTagName("property");
					for (int j = 0; j<properties.getLength(); j++) {
						Node propertyNode = properties.item(j);
						Element propertyElement = (Element)propertyNode;
						//������䣬�Ա�
						if(propertyElement.getAttribute("name").equals("age")){
							System.out.print("���䣺"+propertyElement.getAttribute("value") + "\t");
						}else if(propertyElement.getAttribute("name").equals("sex")){
							System.out.print("�Ա�"+propertyElement.getAttribute("value") + "\t");
						}

					}
					//����
					System.out.println();
				}
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}
}