package h2;

//����j����
public class Minus extends Thread {

	//���빲����Դ
	private Resource resource;
	public Minus(Resource resource){
		this.resource = resource;
	}
	
	@Override
	public void run() {
		while(true){
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			synchronized(resource){
				if(resource.j<=-10){
					return;
				}
				resource.j -= 1;
				System.out.println(Thread.currentThread().getName()+"ʹj-1��j="+resource.j);
			}
			
		}
	}
}
