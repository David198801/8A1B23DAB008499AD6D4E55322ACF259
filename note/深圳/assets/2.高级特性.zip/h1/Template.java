package h1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class Template {

	public static void main(String[] args) {
		
		InputStreamReader isr=null;
		FileWriter fw = null;
		try {
			//���ļ�
			isr = new InputStreamReader(new FileInputStream("C:\\Users\\Administrator\\Desktop\\info.template"),"gbk");
			
			//����stringbuffer
			StringBuffer sb = new StringBuffer();
			//��ȡ��������
			char buffer[] = new char[1024];
			int n = -1;
			while((n=isr.read(buffer))!=-1){
				sb.append(buffer,0,n);
			}
			//�滻���ݣ����
			String string = sb.toString().replace("{name}", "���ӱ�").replace("{class}", "JT99");
			System.out.println(string);
			//д�뵽���ļ�
			fw=new FileWriter("C:\\Users\\Administrator\\Desktop\\info.txt");
			fw.write(string);
			fw.flush();
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			//�ر���
			try {
				if (fw!=null) {
					fw.close();
				}
				if(isr!=null){
					isr.close();
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
}
