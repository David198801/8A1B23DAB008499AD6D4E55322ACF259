package h1;

public class SB {

	public static void main(String[] args) {
	}
}
