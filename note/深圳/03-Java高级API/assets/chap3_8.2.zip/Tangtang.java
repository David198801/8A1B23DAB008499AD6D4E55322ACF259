package chap3_9;

public class Tangtang implements Runnable{
	
	public Object duck,bobby;

	public Tangtang(Object duck,Object bobby){
		this.duck=duck;
		this.bobby=bobby;
	}

	@Override
	public void run() {
		synchronized (bobby) {
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
			synchronized(duck){
				
			}
			System.out.println("�Ѱűȸ��Է���");
		}
		
	}
	
	
}
