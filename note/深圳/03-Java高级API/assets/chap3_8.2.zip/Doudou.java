package chap3_9;

public class Doudou implements Runnable{
	
	public Object duck,bobby;

	public Doudou(Object duck,Object bobby){
		this.duck=duck;
		this.bobby=bobby;
	}

	@Override
	public void run() {
		synchronized (duck) {
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
			synchronized(bobby){
				
			}
			System.out.println("��Ѽ�Ӹ��Է���");
		}
		
	}
	
	
}
