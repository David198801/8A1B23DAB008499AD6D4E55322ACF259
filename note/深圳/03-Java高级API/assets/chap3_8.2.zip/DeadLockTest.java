package chap3_9;

public class DeadLockTest {

	public static void main(String[] args) {
		Object duck=new Object();
		Object bobby=new Object();
		//������
		Thread tangtang=new Thread(new Tangtang(duck, bobby));
		Thread doudou=new Thread(new Doudou(duck, bobby));

		//��������
		tangtang.start();
		doudou.start();
	}
}
