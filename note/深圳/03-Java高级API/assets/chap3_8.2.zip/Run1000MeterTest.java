package chap3_9;

public class Run1000MeterTest {

	public static void main(String[] args) {
		//��1000��
		Run100Meter r = new Run100Meter(1000);
		//10λѡ�ֽ��н���
		for (int i = 1; i <= 10; i++) {
			Thread thread = new Thread(r,i+"��ѡ��");
			thread.start();
		}
	}

}
