package chap3_9;

public class SynchronizedRunnableTest {

	public static void main(String[] args) throws InterruptedException {
		SynchronizedRunnable sr = new SynchronizedRunnable();
		Thread t1 = new Thread(sr);
		Thread t2 = new Thread(sr);
		
		t1.start();
		t2.start();
		
		

	}

}
