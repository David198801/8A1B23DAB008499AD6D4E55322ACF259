package chap3_9;

public class SynchronizedRunnable2Test {

	public static void main(String[] args) {

		SynchronizedRunnable2 sr = new SynchronizedRunnable2();
		Thread t1 = new Thread(sr);
		Thread t2 = new Thread(sr);
		
		t1.start();
		t2.start();

	}

}
