package chap3_9;

public class SellTicket implements Runnable {

	public int ticket = 20;
	public int count = 0;

	@Override
	public void run() {

		while (true) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			synchronized (this) {
				if (ticket > 0) {
					ticket--;
					count++;
					String name = Thread.currentThread().getName();
					System.out.println(name + "�����˵�" + count + "��Ʊ��ʣ��" + ticket
							+ "��Ʊ");
					if (name.equals("��ţ��")) {
						return;
					}
				} else {
					break;
				}
			}
		}

	}
	
}
