package chap3_6;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamTest {

	public static void main(String[] args) {
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream("c:\\myfile.txt");
			String s = "selflsefnlsgbekglsejfsebgl1111";
			//Stringתbyte[]
			byte[] buffer = s.getBytes();
			fos.write(buffer);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				// �ر��ļ�
				fos.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}

	}

}
