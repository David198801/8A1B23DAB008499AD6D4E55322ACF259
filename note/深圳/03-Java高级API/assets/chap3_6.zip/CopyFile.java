package chap3_6;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyFile {

	public static void main(String[] args) {
		// �����ļ�
		String filePath = "c:\\myfile.txt";
		String newFilePath = "d:\\myNewFile.txt";
		
		//�������������
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			//���ļ�
			fis = new FileInputStream(filePath);
			fos = new FileOutputStream(newFilePath);
			//������
			byte[] buffer = new byte[1024];
			//д�ļ�
			int len = 0;
			while ((len=fis.read(buffer))!=-1) {
				fos.write(buffer,0,len);
			}

	

		} catch (FileNotFoundException e) {// ����FileNotFoundException
			e.printStackTrace();
		} catch (IOException e) {// ����IOException
			e.printStackTrace();
		} finally {
			try {
				// �ر��ļ�
				fis.close();
				fos.close();
			} catch (IOException e2) {
				e2.printStackTrace();
			}
		}

	}

}
