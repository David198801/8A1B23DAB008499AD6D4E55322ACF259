package chap3_6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;

public class ReadTest {

	public static void main(String[] args) throws IOException {
		
		File file = new File("C:\\Users\\Administrator\\Desktop\\�½��ı��ĵ�.txt");
		
		FileInputStream fis = new FileInputStream(file);
		int b;
		while((b = fis.read())!=-1) {
			System.out.print((char)b);
		}
		System.out.println();
		//�ر��ļ�
		fis.close();
		
		//���¶�ȡ
		fis = new FileInputStream(file);
		//ʹ���ֽ�������Ϊ������
		byte[] buffer = new byte[1024];
		
		int len = 0;
		while((len = fis.read(buffer))!=-1) {
			System.out.print(new String(buffer,0,len));
		}
		
		System.out.println();
		fis.close();
		
		//���¶�ȡ
		fis = new FileInputStream(file);
		//ָ����ȡ��Χ
		fis.read(buffer,0,buffer.length); 
		String string = new String(buffer);
		System.out.println(string);
		fis.close();
		
		
	
	}
}
