package chap2_4.part1;

public class Test {
	String name;
	String id;
	int age;
	
	//��дequals
	@Override
	public boolean equals(Object anObject) {
		if(this==anObject){
			return true;
		}
		if(anObject instanceof Test){
			Test t=(Test)anObject;
			if(this.name.equals(t.name) && this.id.equals(t.id) && this.age==t.age){
				return true;
			}else{
				return false;
			}
			
		}
		return false;
	}
	
	public static void main(String[] args) {
		Test t1 =new Test();
		Test t2 =new Test();
		Test t3 =new Test();
		Test t4 =new Test();
		
		t2.name = "С��";
		t2.id = "001";
		t2.age = 18;
		
		t3.name = "С��";
		t3.id = "002";
		t3.age = 19;
		
		t4.name = "С��";
		t4.id = "002";
		t4.age = 19;
		
		System.out.println("�Լ����Լ��Ƚϣ�"+t1.equals(t1));
		System.out.println("��ͬ�ıȽϣ�"+t2.equals(t3));
		System.out.println("��ͬ�ıȽϣ�"+t4.equals(t3));
	}
}
