package com.book.test;

import com.book.utils.JdbcUtils;

import java.sql.Connection;

import static org.junit.Assert.*;

public class JdbcUtilsTest {

    @org.junit.Test
    public void test() {

        Connection conn = JdbcUtils.getConnection();
        System.out.println(conn);
        JdbcUtils.close(conn);
        System.out.println(conn);
    }

}