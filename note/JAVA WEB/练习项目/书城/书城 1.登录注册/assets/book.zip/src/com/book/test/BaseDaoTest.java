package com.book.test;

import com.book.bean.User;
import com.book.dao.BaseDao;
import com.book.utils.JdbcUtils;
import org.junit.Test;

import java.sql.Connection;

import static org.junit.Assert.*;

public class BaseDaoTest extends BaseDao<User> {



    @Test
    public void update() throws Exception{
        
        String sql = "insert into t_user(username,password,email) values(?,?,?)";
        update( sql, "test2", "test2", "test2@test.com");

        

    }

    @Test
    public void queryForOne() throws Exception{
        
        String sql = "select id,username,password,email from t_user where id = ?";
        System.out.println(queryForOne( sql, "6"));

        

    }

    @Test
    public void queryForList() throws Exception{
        
        String sql = "select id,username,password,email from t_user where id > ?";
        System.out.println(queryForList( sql, "2"));

        

    }

    @Test
    public void queryForSingleValue() throws Exception{
        
        String sql = "select min(id) from t_user";
        Integer l = queryForSingleValue( sql);
        System.out.println(l);
        

    }
}