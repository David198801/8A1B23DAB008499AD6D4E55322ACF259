package com.book.test;

import com.book.bean.User;
import com.book.service.UserService;
import com.book.service.impl.UserServiseImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserServiceTest {

    UserService service = new UserServiseImpl();

    @Test
    public void registerUser() {
        service.registerUser(new User(null,"test9","test9","abc@163.com"));

    }

    @Test
    public void login() {
        System.out.println(service.login("test5", "test5"));
        System.out.println(service.login("test5", "sdgrg"));
    }

    @Test
    public void existsUsername() {
        System.out.println(service.existsUsername("test9"));
    }
}