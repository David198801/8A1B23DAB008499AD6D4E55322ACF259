/*
SQLyog  v12.2.6 (64 bit)
MySQL - 5.5.62 : Database - book
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`book` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `book`;

/*Table structure for table `t_book` */

DROP TABLE IF EXISTS `t_book`;

CREATE TABLE `t_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `img_path` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

/*Data for the table `t_book` */

insert  into `t_book`(`id`,`name`,`price`,`author`,`sales`,`stock`,`img_path`) values 
(5,'时间简史',30.00,'霍金',468,300,'static/img/default.jpg'),
(10,'时间566',50.00,'霍',544,10,'static/img/default.jpg'),
(11,'巴巴方',35.00,'霍金',454,10,'static/img/default.jpg'),
(13,'时间简史122',35.00,'霍金',45323,11,'static/img/default.jpg'),
(15,'七七88',35.00,'霍金22',183,11,'static/img/default.jpg'),
(16,'时间简史3',50.00,'霍金22',4387,11,'static/img/default.jpg'),
(17,'巴巴',35.00,'霍金22',100,11,'static/img/default.jpg'),
(18,'时间史2',35.00,'霍金',11,11,'static/img/default.jpg'),
(19,'时间简史456',35.00,'霍金22',100,11,'static/img/default.jpg'),
(20,'时间简史5',35.00,'霍金22',100,11,'static/img/default.jpg'),
(21,'时间简史666',35.00,'霍金22',100,11,'static/img/default.jpg'),
(22,'时间简史6',35.00,'霍金22',100,100,'static/img/default.jpg'),
(24,'时间简史6',35.00,'霍金22',100,100,'static/img/default.jpg'),
(25,'时间简史6',35.00,'霍金22',100,100,'static/img/default.jpg'),
(27,'时简史6669',35.00,'霍金22',100,100,'static/img/default.jpg'),
(33,'时间简史2',50.00,'霍金22',100,11,'static/img/default.jpg'),
(34,'时间简史2',788.00,'768',864,8468,'static/img/default.jpg'),
(35,'48648',46.00,'864',486,64,'static/img/default.jpg'),
(36,'48378',135.00,'37',483,783,'static/img/default.jpg'),
(37,'976',646.00,'46',3,7,'static/img/default.jpg'),
(38,'3',3.00,'3',3,3,'static/img/default.jpg'),
(39,'87453',438.00,'8',8,8,'static/img/default.jpg');

/*Table structure for table `t_order` */

DROP TABLE IF EXISTS `t_order`;

CREATE TABLE `t_order` (
  `id` varchar(50) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_order` */

insert  into `t_order`(`id`,`create_time`,`price`,`status`,`user_id`) values 
('001','2021-03-13 15:00:08',60.00,1,1),
('16156203604961','2021-03-13 15:26:00',60.00,0,1),
('16156228965363','2021-03-13 16:08:16',220.00,0,3),
('16156231021893','2021-03-13 16:11:49',85.00,0,3),
('16156239086213','2021-03-13 16:25:08',85.00,0,3),
('16156355843043','2021-03-13 19:39:44',120.00,0,3),
('16156357613363','2021-03-13 19:42:41',120.00,0,3),
('16156358250093','2021-03-13 19:43:45',85.00,0,3);

/*Table structure for table `t_order_item` */

DROP TABLE IF EXISTS `t_order_item`;

CREATE TABLE `t_order_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `price` decimal(11,2) DEFAULT NULL,
  `total_price` decimal(11,2) DEFAULT NULL,
  `order_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `t_order_item` */

insert  into `t_order_item`(`id`,`name`,`count`,`price`,`total_price`,`order_id`) values 
(1,'时间简史',2,60.00,60.00,'001'),
(2,'时间简史',2,60.00,60.00,'16156203604961'),
(3,'时间566',3,150.00,150.00,'16156228965363'),
(4,'巴巴方',1,35.00,35.00,'16156228965363'),
(5,'时间简史122',1,35.00,35.00,'16156228965363'),
(6,'时间566',1,50.00,50.00,'16156231021893'),
(7,'巴巴方',1,35.00,35.00,'16156231021893'),
(8,'时间566',1,50.00,50.00,'16156239086213'),
(9,'巴巴方',1,35.00,35.00,'16156239086213'),
(10,'巴巴方',1,35.00,35.00,'16156355843043'),
(11,'巴巴方',1,35.00,35.00,'16156357613363'),
(12,'巴巴方',1,35.00,35.00,'16156358250093');

/*Table structure for table `t_user` */

DROP TABLE IF EXISTS `t_user`;

CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

/*Data for the table `t_user` */

insert  into `t_user`(`id`,`username`,`password`,`email`) values 
(1,'张三22','abc','aaa@111.a1d'),
(2,'admin','admin','admin@hotmail.com'),
(3,'root','root','root@163.com'),
(4,'test','test','test@test.com'),
(6,'test2','test2','test2@test.com'),
(7,'test3','test3','test3@t.com'),
(8,'test4','test4','test4@t.com'),
(9,'test5','test5','test5@t.com'),
(11,'test9','test9','abc@163.com'),
(12,'test10','test10','abc@163.com'),
(15,'test12','test12','test12@t.t'),
(18,'18sefrsgr','18sefrsgr','sgrrg'),
(19,'sefrsgr','sgdgrdg','sgrrg'),
(20,'20sefrsgr','sgdgrdg','sgrrg'),
(21,'sefsg','sgsr','a@a.a'),
(25,'sefsg4','sgsr','a@a.a'),
(26,'sefsg2','sgsr','a@a.a'),
(27,'sefsg3','sgsr','a@a.a');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
