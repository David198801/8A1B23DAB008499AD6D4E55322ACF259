package com.book.dao.impl;

import com.book.bean.Order;
import com.book.dao.BaseDao;
import com.book.dao.OrderDao;

public class OrderDaoImpl extends BaseDao<Order> implements OrderDao {

    @Override
    public void saveOrder(Order order) {
        String sql = "insert into `t_order`(`id`,`create_time`,`price`,`status`,`user_id`) values(?,?,?,?,?)";
        update(sql, order.getId(), order.getCreateTime(), order.getPrice(), order.getStatus(), order.getUserId());
    }
}
