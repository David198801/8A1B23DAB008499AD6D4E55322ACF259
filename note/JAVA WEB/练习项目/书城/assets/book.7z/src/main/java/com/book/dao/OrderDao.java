package com.book.dao;

import com.book.bean.Order;

public interface OrderDao {
    void saveOrder(Order order);
}
