package com.book.bean;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

public class Cart {

    private Map<Integer,CartItem> items = new LinkedHashMap<>();//购物车商品

    public void addItem(CartItem cartItem){
        CartItem item = items.get(cartItem.getId());
        //如果购物车无商品则添加商品，有则增加商品数量
        if(null==item){
            items.put(cartItem.getId(), cartItem);
        }else{
            item.setCount(item.getCount()+1);
            // 更新金额
            item.setTotalPrice(item.getPrice().multiply(new BigDecimal(item.getCount())));
        }
    }

    public void dedeteItem(Integer id){
        items.remove(id);
    }

    public void clean(){
        items.clear();
    }

    public void updateCount(Integer id,Integer count){
        // 若购物车有商品则更新总金额，无则不处理
        CartItem item = items.get(id);
        if(null!=item){
            item.setCount(count);
            // 更新金额
            items.get(id).setTotalPrice(item.getPrice().multiply(new BigDecimal(item.getCount())));
        }
    }

    public Integer getTotalCount() {
        Integer totalCount = 0;
        for(Map.Entry<Integer,CartItem> entry:items.entrySet()){
            totalCount += entry.getValue().getCount();
        }
        return totalCount;
    }


    public BigDecimal getTotalPrice() {
        BigDecimal totalPrice = new BigDecimal(0);
        for(Map.Entry<Integer,CartItem> entry:items.entrySet()){
            totalPrice = totalPrice.add(entry.getValue().getTotalPrice()) ;
        }
        return totalPrice;
    }


    public Map<Integer, CartItem> getItems() {
        return items;
    }

    public void setItems(Map<Integer, CartItem> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return "Cart{" +
                "items=" + items +
                '}';
    }
}
