package com.book.bean;

import java.util.List;

/**
 * 分页对象模型
 * @param <E> 分页的bean类
 */
public class Page<E> {

    public static final Integer DEFAULT_PAGE_SIZE = 4;

    // 当前页码
    private Integer pageNo;
    // 每页显示数量
    private Integer pageSize=DEFAULT_PAGE_SIZE;
    // 总页码
    private Integer pageTotal;
    // 总记录数
    private Integer itemsCount;
    // 偏移量
    private Integer offset;
    // 分页条的请求地址
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public String toString() {
        return "Page{" +
                "pageNo=" + pageNo +
                ", pageSize=" + pageSize +
                ", pageTotal=" + pageTotal +
                ", itemsCount=" + itemsCount +
                ", offset=" + offset +
                ", url='" + url + '\'' +
                ", pageItems=" + pageItems +
                '}';
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        // 数据边界检查,pageNo=1放后面,防止pageTotal=0的情况
        if(pageNo > pageTotal){
            pageNo = pageTotal;
        }
        if(pageNo < 1){
            pageNo = 1;
        }
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageTotal() {
        return pageTotal;
    }

    public void setPageTotal(Integer pageTotal) {
        this.pageTotal = pageTotal;
    }

    public Integer getItemsCount() {
        return itemsCount;
    }

    public void setItemsCount(Integer itemsCount) {
        this.itemsCount = itemsCount;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public List<E> getPageItems() {
        return pageItems;
    }

    public void setPageItems(List<E> pageItems) {
        this.pageItems = pageItems;
    }

    // 当前页数据
    private List<E> pageItems;

}
