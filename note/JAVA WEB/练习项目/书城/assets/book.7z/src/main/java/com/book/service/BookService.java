package com.book.service;

import com.book.bean.Book;
import com.book.bean.Page;

import java.util.List;

public interface BookService {

    int addBook(Book book);

    int deleteBookById(Integer id);

    int updateBook(Book book);

    Book queryBookById(Integer id);

    List<Book> queryAllBooks();

    Page<Book> page(int pageNo, int pageSize);

    Page<Book> pageByPrice(int pageNo, int pageSize,int minPrice,int maxPrice);
}
