package com.book.dao;

import com.book.bean.OrderItem;

public interface OrderItemDao {
    void saveOrderItem(OrderItem orderItem);
}
