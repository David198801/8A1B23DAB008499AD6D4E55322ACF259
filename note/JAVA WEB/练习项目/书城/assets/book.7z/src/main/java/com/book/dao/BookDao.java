package com.book.dao;

import com.book.bean.Book;

import java.util.List;

public interface BookDao {

    int addBook(Book book);

    int deleteBookById(Integer id);

    int updateBook(Book book);

    Book queryBookById(Integer id);

    List<Book> queryAllBooks();

    int queryForBooksCount();

    List<Book> queryForPageBooks(int offset, int pageSize);

    int queryForPageByPriceCount(int minPrice, int maxPrice);

    List<Book> queryForPageByPriceBooks(int offset, int pageSize, int minPrice, int maxPrice);
}
