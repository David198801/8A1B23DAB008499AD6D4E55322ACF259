package com.book.web;

import com.book.bean.Book;
import com.book.bean.Page;
import com.book.service.BookService;
import com.book.service.impl.BookServiceImpl;
import com.book.utils.WebUitls;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ClientBookServlet extends BaseServlet {

    private BookService bookService = new BookServiceImpl();

    protected void page(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 默认页码为1
        int pageNo = WebUitls.parsInt(req.getParameter("pageNo"), 1);
        int pageSize = WebUitls.parsInt(req.getParameter("pageSize"), Page.DEFAULT_PAGE_SIZE);

        Page<Book> page = bookService.page(pageNo,pageSize);
        page.setUrl("client/bookServlet?action=page");

        req.setAttribute("page",page);

        req.getRequestDispatcher("/pages/client/index.jsp").forward(req,resp);
    }


    protected void pageByPrice(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 默认页码为1
        int pageNo = WebUitls.parsInt(req.getParameter("pageNo"), 1);
        int pageSize = WebUitls.parsInt(req.getParameter("pageSize"), Page.DEFAULT_PAGE_SIZE);

        int minPrice = WebUitls.parsInt(req.getParameter("min"), 0);
        int maxPrice = WebUitls.parsInt(req.getParameter("max"), Integer.MAX_VALUE);

        Page<Book> page = bookService.pageByPrice(pageNo,pageSize,minPrice,maxPrice);

        // 如果有最大/最小值则追加到参数
        StringBuffer sb = new StringBuffer("client/bookServlet?action=pageByPrice");
        if(null!=req.getParameter("min")){
            sb.append("&min=" + minPrice);
        }
        if(null!=req.getParameter("max")){
            sb.append("&max=" + maxPrice);
        }
        page.setUrl(sb.toString());

        req.setAttribute("page",page);

        req.getRequestDispatcher("/pages/client/index.jsp").forward(req,resp);
    }
}
