package com.book.dao.impl;

import com.book.bean.Book;
import com.book.dao.BaseDao;
import com.book.dao.BookDao;

import java.util.List;

public class BookDaoImpl extends BaseDao<Book> implements BookDao {
    @Override
    public int addBook(Book book) {
        String sql = "INSERT INTO `t_book`(`name`, `price`, `author`, `sales`, `stock`, `img_path`) VALUES (?, ?, ?, ?, ?, ?)";
        return update(sql,book.getName(),book.getPrice(),book.getAuthor(),book.getSales(),book.getStock(),book.getImgPath());
    }

    @Override
    public int deleteBookById(Integer id) {
        String sql = "delete from `t_book` where `id`=?";
        return update(sql, id);
    }

    @Override
    public int updateBook(Book book) {
        String sql = "update `t_book` set `name`=?, `price`=?, `author`=?, `sales`=?, `stock`=?, `img_path`=? where id=?" ;
        return update(sql,book.getName(),book.getPrice(),book.getAuthor(),book.getSales(),book.getStock(),book.getImgPath(),book.getId());
    }

    @Override
    public Book queryBookById(Integer id) {
        String sql = "select `id`,`name`, `price`, `author`, `sales`, `stock`, `img_path` from `t_book` where id=?";
        return queryForOne(sql, id);
    }

    @Override
    public List<Book> queryAllBooks() {
        String sql = "select `id`,`name`, `price`, `author`, `sales`, `stock`, `img_path` from `t_book`";
        return queryForList(sql);
    }

    @Override
    public int queryForBooksCount() {
        String sql = "select count(*) from `t_book`";
        Number count = queryForSingleValue(sql);
        return count.intValue();
    }

    @Override
    public List<Book> queryForPageBooks(int offset, int pageSize) {
        String sql = "select `id`,`name`, `price`, `author`, `sales`, `stock`, `img_path` from `t_book` limit ?,?";
        return queryForList(sql,offset,pageSize);
    }

    @Override
    public int queryForPageByPriceCount(int minPrice, int maxPrice) {
        String sql = "select count(*) from `t_book` where `price` between ? and ?";
        Number count = queryForSingleValue(sql,minPrice,maxPrice);
        return count.intValue();
    }

    @Override
    public List<Book> queryForPageByPriceBooks(int offset, int pageSize, int minPrice, int maxPrice) {
        String sql = "select `id`,`name`, `price`, `author`, `sales`, `stock`, `img_path` from `t_book` where `price` between ? and ? limit ?,?";
        return queryForList(sql,minPrice,maxPrice,offset,pageSize);
    }
}
