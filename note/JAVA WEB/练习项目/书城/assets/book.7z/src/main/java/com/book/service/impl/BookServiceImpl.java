package com.book.service.impl;

import com.book.bean.Book;
import com.book.bean.Page;
import com.book.dao.BookDao;
import com.book.dao.impl.BookDaoImpl;
import com.book.service.BookService;

import java.util.List;

public class BookServiceImpl implements BookService {

    BookDao bookDao = new BookDaoImpl();

    @Override
    public int addBook(Book book) {
        return bookDao.addBook(book);
    }

    @Override
    public int deleteBookById(Integer id) {
        return bookDao.deleteBookById(id);
    }

    @Override
    public int updateBook(Book book) {
        return bookDao.updateBook(book);
    }

    @Override
    public Book queryBookById(Integer id) {
        return bookDao.queryBookById(id);
    }

    @Override
    public List<Book> queryAllBooks() {
        return bookDao.queryAllBooks();
    }

    @Override
    public Page<Book> page(int pageNo, int pageSize) {
        Page<Book> page = new Page<>();

        // 设置每页大小
        page.setPageSize(pageSize);


        int booksCount = bookDao.queryForBooksCount();
        page.setItemsCount(booksCount);

        // 计算总页数
        int pageTotal = booksCount/pageSize;
        if(booksCount%pageSize>0){
            pageTotal++;
        }
        // 设置总页数
        page.setPageTotal(pageTotal);


        // 设置当前页码，因为边界检查，要写在pageTotal后面
        page.setPageNo(pageNo);
        //pageNo = page.getPageNo();


        // 设置偏移量
        int offset = (page.getPageNo()-1)*pageSize;
        page.setOffset(offset);
        // 获取页面图书
        page.setPageItems(bookDao.queryForPageBooks(offset,pageSize));

        return page;
    }

    @Override
    public Page<Book> pageByPrice(int pageNo, int pageSize,int minPrice,int maxPrice) {
        Page<Book> page = new Page<>();

        // 设置每页大小
        page.setPageSize(pageSize);


        int booksCount = bookDao.queryForPageByPriceCount(minPrice,maxPrice);
        page.setItemsCount(booksCount);

        // 计算总页数
        int pageTotal = booksCount/pageSize;
        if(booksCount%pageSize>0){
            pageTotal++;
        }
        // 设置总页数
        page.setPageTotal(pageTotal);


        // 设置当前页码，因为边界检查，要写在pageTotal后面
        page.setPageNo(pageNo);
        //pageNo = page.getPageNo();


        // 设置偏移量
        int offset = (page.getPageNo()-1)*pageSize;
        page.setOffset(offset);
        // 获取页面图书
        page.setPageItems(bookDao.queryForPageByPriceBooks(offset,pageSize,minPrice,maxPrice));

        return page;
    }
}
