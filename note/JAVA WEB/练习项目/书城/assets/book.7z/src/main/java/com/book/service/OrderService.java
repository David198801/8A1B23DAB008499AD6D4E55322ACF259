package com.book.service;

import com.book.bean.Cart;

public interface OrderService {
    String createOrder(Cart cart,Integer userId);
}
