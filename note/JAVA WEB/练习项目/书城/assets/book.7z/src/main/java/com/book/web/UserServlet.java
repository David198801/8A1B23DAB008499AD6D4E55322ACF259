package com.book.web;

import com.book.bean.User;
import com.book.service.UserService;
import com.book.service.impl.UserServiseImpl;
import com.google.code.kaptcha.Constants;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.google.code.kaptcha.Constants.KAPTCHA_SESSION_KEY;

public class UserServlet extends BaseServlet {

    UserService service = new UserServiseImpl();

    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        // 登录
        User user = service.login(username, password);
        if (null != user) {
            // 登录成功

            // 保存登录信息到session
            HttpSession session = req.getSession();
            session.setAttribute("user", user);

            resp.sendRedirect("/book/pages/user/login_success.jsp");
        } else {
            // 登录失败
            req.setAttribute("msg", "用户名或密码错误");
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req, resp);
        }
    }


    protected void logout(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getSession().invalidate();
        resp.sendRedirect("/book/index.jsp");
    }


    protected void regist(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取验证码,马上删除
        String kaptcha = (String) req.getSession().getAttribute(KAPTCHA_SESSION_KEY);
        req.getSession().removeAttribute(KAPTCHA_SESSION_KEY);
        String token = req.getParameter("code");
        if (null != token && token.equals(kaptcha)) {

            // 获取请求参数
            String username = req.getParameter("username");
            String password = req.getParameter("password");
            String email = req.getParameter("email");

            // 确认用户名是否可用
            if (!service.existsUsername(username)) {
                // 可用则保存到数据库
                service.registerUser(new User(null, username, password, email));
                // 跳转到注册成功页面
                resp.sendRedirect("/book/pages/user/regist_success.jsp");
            } else {
                // 跳转到注册失败页面
                req.setAttribute("msg", "用户名已存在");
                req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);

            }
        } else {
            // 跳转到注册失败页面
            req.setAttribute("msg", "验证码错误");
            req.getRequestDispatcher("/pages/user/regist.jsp").forward(req, resp);
        }
    }


    protected void existUsername(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String username = req.getParameter("username");
        boolean result = service.existsUsername(username);
        Map<String, Boolean> resultMap = new HashMap<>();
        resultMap.put(username, result);
        resp.getWriter().write(new Gson().toJson(resultMap));
    }


}
