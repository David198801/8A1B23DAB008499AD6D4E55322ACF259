package com.book.test;

import com.book.bean.Cart;
import com.book.bean.CartItem;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class CartTest {

    @Test
    public void test() {
        Cart cart = new Cart();
        cart.addItem(new CartItem(1,"a",new BigDecimal(100),1,new BigDecimal(100)));
        cart.addItem(new CartItem(1,"a",new BigDecimal(100),1,new BigDecimal(100)));
        cart.addItem(new CartItem(2,"b",new BigDecimal(100),1,new BigDecimal(100)));
        System.out.println(cart.toString());
        System.out.println(cart.getTotalCount());
        System.out.println(cart.getTotalPrice());

        System.out.println("----------");

        cart.dedeteItem(2);
        System.out.println(cart.toString());
        System.out.println(cart.getTotalCount());
        System.out.println(cart.getTotalPrice());

        System.out.println("----------");
        cart.updateCount(1,10);
        System.out.println(cart.toString());
        System.out.println(cart.getTotalCount());
        System.out.println(cart.getTotalPrice());

        System.out.println("----------");
        cart.clean();
        System.out.println(cart.toString());
        System.out.println(cart.getTotalCount());
        System.out.println(cart.getTotalPrice());

    }

}