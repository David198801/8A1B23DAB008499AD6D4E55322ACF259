package com.book.test;

import com.book.bean.User;
import com.book.dao.impl.UserDaoImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserDaoImplTest {

    UserDaoImpl u = new UserDaoImpl();

    @Test
    public void queryUserByUserName() {
        System.out.println(u.queryUserByUserName("abc"));
        System.out.println(u.queryUserByUserName("sefsgyh"));
    }

    @Test
    public void queryUserByUsernameAndPassword() {
        System.out.println(u.queryUserByUsernameAndPassword("abc","abc"));
        System.out.println(u.queryUserByUsernameAndPassword("abc","aaa"));
        System.out.println(u.queryUserByUsernameAndPassword("sgsg","rjy"));
    }

    @Test
    public void saveUser() {
        int i = u.saveUser(new User(null,"test4","test4","test4@t.com"));
        System.out.println(i);
    }
}