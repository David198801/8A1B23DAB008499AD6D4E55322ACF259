package com.book.service;

import com.book.bean.Cart;
import com.book.bean.CartItem;
import com.book.service.impl.OrderServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class OrderServiceTest {

    @Test
    public void createOrder() {
        Cart cart = new Cart();
        cart.addItem(new CartItem(5,"时间简史",new BigDecimal(30),2,new BigDecimal(60)));


        OrderService orderService = new OrderServiceImpl();
        orderService.createOrder(cart,1);
    }
}