package com.book.test;

import com.book.bean.Book;
import com.book.bean.Page;
import com.book.service.BookService;
import com.book.service.impl.BookServiceImpl;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.*;

public class BookServiceTest {

    BookService bookService = new BookServiceImpl();

    @Test
    public void addBook() {
        bookService.addBook(new Book(null,"测试书2", new BigDecimal(100), "aaa", 888, 0,null));
    }

    @Test
    public void deleteBookById() {
        bookService.deleteBookById(5);
    }

    @Test
    public void updateBook() {
        bookService.updateBook(new Book(5,"试书2", new BigDecimal(1000), "aaa", 8888, 0,null));
    }

    @Test
    public void queryBookById() {
        System.out.println(bookService.queryBookById(1));
    }

    @Test
    public void queryAllBooks() {
        System.out.println(bookService.queryAllBooks());
    }


    @Test
    public void page() {
        Page<Book> page = bookService.page(2,4);
        for(Book book :page.getPageItems()){
            System.out.println(book);
        }
        System.out.println(page.getPageTotal());
    }
}