package com.book.test;

import com.book.bean.OrderItem;
import com.book.dao.impl.OrderItemDaoImpl;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;

public class OrderItemDaoImplTest {

    @Test
    public void saveOrderItem() {
        OrderItemDaoImpl dao = new OrderItemDaoImpl();
        dao.saveOrderItem(new OrderItem(null,"时间简史",2,new BigDecimal(30.00),new BigDecimal(60),"001"));
    }
}