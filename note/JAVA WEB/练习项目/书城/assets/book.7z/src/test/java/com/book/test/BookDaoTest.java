package com.book.test;

import com.book.bean.Book;
import com.book.dao.BookDao;
import com.book.dao.impl.BookDaoImpl;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.*;

public class BookDaoTest {

    BookDao bookDao = new BookDaoImpl();

    @Test
    public void addBook() {
        bookDao.addBook(new Book(null, "测试书1", new BigDecimal(1000), "aaa", 8888, 0, null));
    }

    @Test
    public void deleteBookById() {
        bookDao.deleteBookById(3);
    }

    @Test
    public void updateBook() {
        bookDao.updateBook(new Book(4, "测试书2", new BigDecimal(1000), "aaa", 8888, 0, null));
    }

    @Test
    public void queryBookById() {
        System.out.println(bookDao.queryBookById(4));
    }

    @Test
    public void queryAllBooks() {
        System.out.println(bookDao.queryAllBooks());
    }

    @Test
    public void queryForBooksCount() {
        System.out.println(bookDao.queryForBooksCount());
    }

    @Test
    public void queryForPageBooks() {
        System.out.println(bookDao.queryForPageBooks(12, 4));
    }
}