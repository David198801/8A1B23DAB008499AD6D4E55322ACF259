package com.lzb.document.controller;

import com.lzb.document.pojo.Student;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/ajaxtest")
public class AjaxController {

    @RequestMapping("/userServlet")
    @ResponseBody
    public Map<String,Object> userServlet(){
        Map<String, Object> map = new HashMap<>();
        map.put("isUsernameExists", true);
        return map;
    }

    @RequestMapping("/studentServlet")
    @ResponseBody
    public Student studentServlet(){
        Student student = new Student(1,"张三",20,"a1","xxxxxx");
        return student;
    }


}
