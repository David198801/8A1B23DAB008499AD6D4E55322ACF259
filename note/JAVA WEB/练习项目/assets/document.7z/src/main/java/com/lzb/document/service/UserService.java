package com.lzb.document.service;

public interface UserService {
    boolean login(String username,String password);
}
