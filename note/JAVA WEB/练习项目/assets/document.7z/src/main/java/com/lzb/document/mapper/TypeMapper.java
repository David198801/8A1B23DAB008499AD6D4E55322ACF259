package com.lzb.document.mapper;

import com.lzb.document.pojo.Type;

import java.util.List;

public interface TypeMapper {
    int deleteTypeById(Integer id);

    int addType(Type type);

    Type getTypeById(Integer id);

    int updateType(Type type);

    List<Type> getAllTypes();

}