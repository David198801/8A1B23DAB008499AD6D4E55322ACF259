package com.lzb.document.pojo;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public class Document {
    private Integer id;

    private Integer typeid;

    private String name;

    private String describle;

    private String auth;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date pushdate;

    public Document() {
    }

    public Document(Integer id, Integer typeid, String name, String describle, String auth, Date pushdate) {
        this.id = id;
        this.typeid = typeid;
        this.name = name;
        this.describle = describle;
        this.auth = auth;
        this.pushdate = pushdate;
    }

    @Override
    public String toString() {
        return "Document{" +
                "id=" + id +
                ", typeid=" + typeid +
                ", name='" + name + '\'' +
                ", describle='" + describle + '\'' +
                ", auth='" + auth + '\'' +
                ", pushdate=" + pushdate +
                '}';
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTypeid() {
        return typeid;
    }

    public void setTypeid(Integer typeid) {
        this.typeid = typeid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getDescrible() {
        return describle;
    }

    public void setDescrible(String describle) {
        this.describle = describle == null ? null : describle.trim();
    }

    public String getAuth() {
        return auth;
    }

    public void setAuth(String auth) {
        this.auth = auth == null ? null : auth.trim();
    }

    public Date getPushdate() {
        return pushdate;
    }

    public void setPushdate(Date pushdate) {
        this.pushdate = pushdate;
    }
}