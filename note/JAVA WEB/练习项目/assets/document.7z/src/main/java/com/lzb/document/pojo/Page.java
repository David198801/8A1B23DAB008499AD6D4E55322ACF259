package com.lzb.document.pojo;

import java.util.List;

/**
 * 分页对象模型
 * @param <E> 分页的bean类
 */
public class Page<E> {

    public static final Integer DEFAULT_PAGE_SIZE = 4;

    // 当前页码
    private Integer pageNo;
    // 每页显示数量
    private Integer pageSize=DEFAULT_PAGE_SIZE;
    // 总页码
    private Integer pageTotal;
    // 总记录数
    private Integer itemsCount;


    // 当前页数据
    private List<E> pageItems;


    @Override
    public String toString() {
        return "Page{" +
                "pageNo=" + pageNo +
                ", pageSize=" + pageSize +
                ", pageTotal=" + pageTotal +
                ", itemsCount=" + itemsCount +
                ", pageItems=" + pageItems +
                '}';
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageTotal() {
        return pageTotal;
    }

    public void setPageTotal(Integer pageTotal) {
        this.pageTotal = pageTotal;
    }

    public Integer getItemsCount() {
        return itemsCount;
    }

    public void setItemsCount(Integer itemsCount) {
        this.itemsCount = itemsCount;
    }

    public List<E> getPageItems() {
        return pageItems;
    }

    public void setPageItems(List<E> pageItems) {
        this.pageItems = pageItems;
    }

}
