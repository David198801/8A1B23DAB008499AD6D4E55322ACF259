package com.lzb.document.service;

import com.lzb.document.pojo.Document;
import com.lzb.document.pojo.Page;
import com.lzb.document.query.DocumentQuery;

import java.util.List;

public interface DocumentService {
    void deleteById(Integer id);

    void addDocument(Document document);

    Document getDocumentById(Integer id);

    List<Document> getAllDocuments();



    void updateDocument(Document document);

    Page<Document> getPageByCondition(DocumentQuery documentQuery);
}
