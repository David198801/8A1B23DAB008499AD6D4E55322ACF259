package com.lzb.document.service;

import java.util.List;

import com.lzb.document.pojo.Type;

public interface TypeService {
    List<Type> getAllTypes();

    Type getTypeById(Integer id);
}
