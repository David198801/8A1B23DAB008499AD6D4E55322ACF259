package com.lzb.document.mapper;

import com.lzb.document.pojo.Document;
import com.lzb.document.query.DocumentQuery;

import java.util.List;

public interface DocumentMapper {
    int deleteDocumentById(Integer id);

    int addDocument(Document document);

    Document getDocumentById(Integer id);

    List<Document> getAllDocuments();

    Integer getAllDocumentsCount();


    int updateDocument(Document document);

    List<Document> getDocumentsByCondition(DocumentQuery documentQuery);

    Integer getDocumentsByConditionCount(DocumentQuery documentQuery);
}