package com.lzb.document.controller;

import com.lzb.document.pojo.Document;
import com.lzb.document.pojo.Page;
import com.lzb.document.pojo.Type;
import com.lzb.document.query.DocumentQuery;
import com.lzb.document.service.DocumentService;
import com.lzb.document.service.TypeService;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.UUID;

@Controller
@RequestMapping("document")
public class DocumentController {

    @Autowired
    private DocumentService documentService;

    @Autowired
    private TypeService typeService;

    @RequestMapping("/doList")
    public String doList(
            Model model,
            @RequestParam(value = "pageNo",required = false) Integer pageNo,
            @RequestParam(value = "pageSize",required = false) Integer pageSize,
            @RequestParam(value = "typeid",required = false) Integer typeid
    ){
        List<Type> types = typeService.getAllTypes();
        model.addAttribute("types", types);

        DocumentQuery documentQuery = new DocumentQuery();
        documentQuery.setPageNo(pageNo==null?1:pageNo);
        documentQuery.setPageSize(pageSize==null?4:pageSize);
        documentQuery.setTypeid(typeid);

        Page<Document> page = documentService.getPageByCondition(documentQuery);
        model.addAttribute("page", page);


        return "list";
    }


    @RequestMapping("/add")
    public String add(Model model){
        List<Type> types = typeService.getAllTypes();
        model.addAttribute("types", types);
        return "add";
    }

    @RequestMapping("/doAdd")
    public String doAdd(
            Document document,
            @RequestParam("file") MultipartFile multipartFile,
            HttpServletRequest request
    ){
        if(multipartFile!=null){
            String originalFilename = multipartFile.getOriginalFilename();
            String fileName = UUID.randomUUID() + originalFilename.substring(originalFilename.indexOf("."));
            File saveFile = new File(request.getServletContext().getRealPath("/upload") + File.separator + fileName);
            InputStream inputStream = null;
            try {
                inputStream = multipartFile.getInputStream();
                FileUtils.copyInputStreamToFile(inputStream,saveFile);
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                if (inputStream!=null){
                    try {
                        inputStream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        documentService.addDocument(document);
        return "redirect:/document/doList";
    }

    @RequestMapping("/doDelete")
    public String doDelete(@RequestParam("id") Integer id){
        documentService.deleteById(id);
        return "redirect:/document/doList";
    }

    @GetMapping("/{id}")
    public String doShow(
            Model model,
            @PathVariable("id") Integer id
    ){
        Document document = documentService.getDocumentById(id);

        model.addAttribute("document", document);

        Type type = typeService.getTypeById(document.getTypeid());
        model.addAttribute("type", type);
        return "show";
    }

    @RequestMapping("/edit")
    public String edit(
            Model model,
            @RequestParam("id") Integer id
    ){
        Document document = documentService.getDocumentById(id);

        model.addAttribute("document", document);

        List<Type> types = typeService.getAllTypes();
        model.addAttribute("types", types);
        return "edit";
    }

    @RequestMapping("/doUpdate")
    public String doUpdate(Document document){
        documentService.updateDocument(document);
        return "redirect:/document/doList";
    }

}
