package com.lzb.document.service.impl;

import com.lzb.document.service.UserService;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    @Override
    public boolean login(String username, String password) {
        return (username.equals("root") && password.equals("root"));
    }
}
