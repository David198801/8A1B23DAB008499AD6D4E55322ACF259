package com.lzb.document.service.impl;

import com.lzb.document.mapper.DocumentMapper;
import com.lzb.document.pojo.Document;
import com.lzb.document.pojo.Page;
import com.lzb.document.query.DocumentQuery;
import com.lzb.document.service.DocumentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class DocumentServiceImpl implements DocumentService {
    @Resource
    private DocumentMapper documentMapper;


    // 删除Document
    @Override
    public void deleteById(Integer id) {
        documentMapper.deleteDocumentById(id);
    }

    // 添加Document
    @Override
    public void addDocument(Document document) {
        documentMapper.addDocument(document);
    }

    // 获取Document
    @Override
    public Document getDocumentById(Integer id) {
        return documentMapper.getDocumentById(id);
    }

    // 获取所有Document
    @Override
    public List<Document> getAllDocuments() {
        return documentMapper.getAllDocuments();
    }


    // 更新Document
    @Override
    public void updateDocument(Document document) {
        documentMapper.updateDocument(document);
    }

    // 根据条件获取Document分页
    @Override
    public Page<Document> getPageByCondition(DocumentQuery documentQuery) {
        int pageNo = documentQuery.getPageNo();
        int pageSize = documentQuery.getPageSize();

        Page<Document> page = new Page<>();
        if (documentQuery == null) {
            documentQuery = new DocumentQuery();
        }

        int itemsCount = documentMapper.getDocumentsByConditionCount(documentQuery);

        int pageTotal = itemsCount / pageSize;
        if (itemsCount % pageSize > 0) {
            pageTotal++;
        }


        // 数据边界检查,pageNo=1放后面,防止pageTotal=0的情况
        if(pageNo > pageTotal){
            pageNo = pageTotal;
        }
        if(pageNo < 1){
            pageNo = 1;
        }
        documentQuery.setPageNo(pageNo);
        documentQuery.setPageSize(pageSize);


        page.setPageNo(pageNo);
        page.setItemsCount(itemsCount);
        page.setPageTotal(pageTotal);
        page.setPageSize(pageSize);
        List<Document> documents = documentMapper.getDocumentsByCondition(documentQuery);
        page.setPageItems(documents);

        return page;
    }


}
