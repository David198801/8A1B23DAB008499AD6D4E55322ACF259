package com.lzb.document.service;

import com.lzb.document.pojo.Type;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

import static org.junit.Assert.*;

public class TypeServiceTest {

    @Test
    public void getAllTypes() {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        TypeService typeServiceImpl = context.getBean("typeServiceImpl", TypeService.class);
        List<Type> allTypes = typeServiceImpl.getAllTypes();
        for (Type type : allTypes) {
            System.out.println(type);
        }
    }
}