package com.lzb.document.service;

import com.lzb.document.pojo.Document;
import com.lzb.document.pojo.Page;
import com.lzb.document.query.DocumentQuery;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;
import java.util.Scanner;

import static org.junit.Assert.*;

public class DocumentServiceTest {

    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    DocumentService documentService = context.getBean("documentServiceImpl", DocumentService.class);


    @Test
    public void deleteById() {
        documentService.deleteById(1012);
    }

    @Test
    public void addDocument() {
        Document document = new Document();
        document.setId(1012);
        documentService.addDocument(document);
    }

    @Test
    public void getDocumentById() {
        System.out.println(documentService.getDocumentById(1011));
    }

    @Test
    public void getAllDocuments() {
        List<Document> documents = documentService.getAllDocuments();
        for (Document document : documents) {
            System.out.println(document);
        }

    }


    @Test
    public void updateDocument() {
        Document document = new Document();
        document.setId(1012);
        document.setName("sgsefsef");
        documentService.updateDocument(document);
    }

    @Test
    public void getPageByCondition() {

        DocumentQuery documentQuery = new DocumentQuery();
        // documentQuery.setAuth("张");
        // documentQuery.setTypeid(1);

        Scanner scanner = new Scanner(System.in);

        int i = 1;
        while (true){
            documentQuery.setPageNo(i);
            documentQuery.setPageSize(3);
            Page<Document> page = documentService.getPageByCondition(documentQuery);

            List<Document> pageItems = page.getPageItems();
            System.out.println("--------------------------");
            for (Document document : pageItems) {
                System.out.println(document);
            }
            System.out.println("【"+page.getPageNo()+"/"+page.getPageTotal()+"】，共有"+page.getItemsCount()+"条记录");
            System.out.println("--------------------------");

            System.out.println("请输入页码：");
            i = scanner.nextInt();
        }

    }
}