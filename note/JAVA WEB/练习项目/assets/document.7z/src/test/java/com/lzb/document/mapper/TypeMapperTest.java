package com.lzb.document.mapper;

import com.lzb.document.pojo.Type;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import static org.junit.Assert.*;

public class TypeMapperTest {

    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    TypeMapper typeMapper = context.getBean("typeMapper", TypeMapper.class);


    @Test
    public void deleteTypeById() {
        typeMapper.deleteTypeById(5);
    }

    @Test
    public void addType() {
        Type type = new Type(5, "dfhtjf订单");
        typeMapper.addType(type);
    }

    @Test
    public void getTypeById() {
        Type typeById = typeMapper.getTypeById(4);
        System.out.println(typeById);
    }

    @Test
    public void updateType() {
        Type type = new Type(5, "订单");
        typeMapper.updateType(type);
    }
}