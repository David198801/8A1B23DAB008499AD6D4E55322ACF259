package com.lzb.document.mapper;

import com.lzb.document.pojo.Document;
import com.lzb.document.query.DocumentQuery;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

public class DocumentMapperTest {
    ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
    DocumentMapper documentMapper = context.getBean("documentMapper", DocumentMapper.class);

    @Test
    public void deleteDocumentById() {
        documentMapper.deleteDocumentById(1005);
    }

    @Test
    public void addDocument() {
        Document document = new Document(1005,1,"sttsete","sfefs","uploader",new Date());
        documentMapper.addDocument(document);
    }

    @Test
    public void getDocumentById() {
        Document document = documentMapper.getDocumentById(1004);
        System.out.println(document);
    }

    @Test
    public void updateDocument() {
        Document document = new Document(1005,2,"sttsete","sfefs","uploader",new Date());
        documentMapper.updateDocument(document);
    }

    @Test
    public void getDocumentsByCondition() {
        DocumentQuery documentQuery = new DocumentQuery();
        documentQuery.setName("xxxx");
        List<Document> documentByCondition = documentMapper.getDocumentsByCondition(documentQuery);
        for (Document document : documentByCondition) {
            System.out.println(document);
        }
    }

    @Test
    public void getDocumentsByConditionCount() {
        DocumentQuery documentQuery = new DocumentQuery();
        documentQuery.setName("xxxx");
        Integer count = documentMapper.getDocumentsByConditionCount(documentQuery);
        System.out.println(count);
    }
}