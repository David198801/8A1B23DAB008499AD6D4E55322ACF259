/*
SQLyog  v12.2.6 (64 bit)
MySQL - 5.5.62 : Database - document
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`document` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `document`;

/*Table structure for table `t_doc` */

DROP TABLE IF EXISTS `t_doc`;

CREATE TABLE `t_doc` (
  `ID` int(8) NOT NULL COMMENT '文档编号',
  `TYPEID` int(8) DEFAULT NULL COMMENT '类型编号',
  `NAME` varchar(32) DEFAULT NULL COMMENT '文档名称',
  `DESCRIBLE` varchar(255) DEFAULT NULL COMMENT '文档摘要',
  `AUTH` varchar(32) DEFAULT NULL COMMENT '上传人',
  `PUSHDATE` datetime DEFAULT NULL COMMENT '上传时间',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_doc` */

insert  into `t_doc`(`ID`,`TYPEID`,`NAME`,`DESCRIBLE`,`AUTH`,`PUSHDATE`) values 
(1001,1,'十万个为什么','讲述人类自开始以来的各种问题','张三','2016-01-01 00:00:00'),
(1002,4,'世界未解之谜','各种对外星人的猜测','杰克','2015-05-01 00:00:00'),
(1004,3,'Java入门到精通','如何培养一个屌丝男逆袭','奈何天','2015-02-03 00:00:00'),
(1006,1,'恢复xxxx经济','egrhdthtfj','张三','2021-04-07 15:41:55'),
(1007,4,'集合xxxx匿名','gyjgyy','金五','2021-04-07 15:41:58'),
(1008,2,'结合xxxx还能','jygjgyk','张三','2021-04-07 15:42:00'),
(1009,3,'闪电发货','uhkilh','金六','2021-04-07 15:42:02'),
(1010,4,'公管局','kjkrtfherg','张三','2021-04-07 15:42:03'),
(1011,2,'的动态规定','wefwefwef','张三','2021-04-07 15:42:04'),
(32058,1,'java入门','摘要摘要摘要摘要','张三','1999-09-09 00:00:00'),
(95843,1,'java入门','摘要摘要摘要摘要','张三','1999-09-09 00:00:00'),
(116021,1,'java入门','摘要摘要摘要摘要','张三','1999-09-09 00:00:00'),
(193969,2,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(272546,2,'发鬼地方222','摘要摘要摘要摘要','张三56','2021-01-01 00:00:00'),
(285110,1,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(311428,1,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(490322,1,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(603380,1,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(625701,4,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(641792,1,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(669806,4,'kl','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(742359,2,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(743338,3,'好久没规划','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(774183,1,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(799719,1,'java入门','摘要摘要摘要摘要','张三','1999-09-09 00:00:00'),
(806602,2,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00'),
(949611,1,'java入门','摘要摘要摘要摘要','张三','2021-01-01 00:00:00');

/*Table structure for table `t_type` */

DROP TABLE IF EXISTS `t_type`;

CREATE TABLE `t_type` (
  `ID` int(8) NOT NULL COMMENT '类型编号',
  `NAME` varchar(32) DEFAULT NULL COMMENT '类型名称',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t_type` */

insert  into `t_type`(`ID`,`NAME`) values 
(1,'科普类'),
(2,'小说类'),
(3,'技术类'),
(4,'科幻类');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
