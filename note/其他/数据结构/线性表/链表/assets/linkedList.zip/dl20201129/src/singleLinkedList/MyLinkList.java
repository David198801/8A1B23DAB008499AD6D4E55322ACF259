package singleLinkedList;

public class MyLinkList {

	private Node head;
	private int size = 0;

	public MyLinkList() {
		head = new Node();
		head.next = null;
	}
	
	//��ӡ����
	public void print() {
		Node rnode = head;
		while (rnode.next != null){
			rnode = rnode.next;
			System.out.print(rnode.e+" ");
		}
		System.out.println();
			
	}

	//���뵽ĩβ
	public void add(Object e) {
		Node node = new Node(e);
		Node rnode = head;

		while (rnode.next != null)
			rnode = rnode.next;
		rnode.next = node;
		size++;
	}
	
	//���뵽��ͷ
	public void addFirst(Object e) {
		Node node = new Node(e);
		node.next = head.next;
		head.next = node;
		size++;
	}
	

	//���뵽ָ��λ�ã���0��ʼ��head������
	public void insert(Object e,int x) {
		Node newNode = new Node(e);
		Node insertNode = head;
		for (int i = 0; i < x; i++) {
			insertNode = insertNode.next;
		}
		newNode.next = insertNode.next;
		insertNode.next = newNode;
		size++;
	}
	
	//���ָ��λ��
	public void print(int x){
		if(x>size-1||x<0){
			System.out.println("������Χ");
			
		}else{
			Node node = head;
			for (int i = 0; i < x; i++) {
				node = node.next;
			}
			System.out.println(node.next.e);
		}
		
	}
	
	//ɾ����λ
	public void deleteFirst(){
		if(head.next==null){
			System.out.println("����Ϊ��");
		}else {
			head.next = head.next.next;
			size--;
		}
		
	}
	
	//ɾ��ĩλ
	public void deleteLast(){
		if(head.next==null){
			System.out.println("����Ϊ��");
		}else {
			Node node = head;
			for (int i = 0; i < size-1; i++) {
				node = node.next;
			}
			node.next = null;
			size--;
		}
		
	}
	
	//ɾ��ָ��λ��
	public void delete(int x){
		if(x<0||x>size-1){
			System.out.println("������Χ");
		}else{
			Node node = head;
			for (int i = 0; i < x; i++) {
				node = node.next;
			}
			//���账��x==size-1�������node.next.nextΪnull
			node.next = node.next.next;
			size--;
		}
	}
	
	//�޸�ָ��λ��
	public void replace(Object e,int x){
		if(x<0||x>size-1){
			System.out.println("������Χ");
		}else{
			Node node = head;
			for (int i = 0; i < x+1; i++) {
				node = node.next;
			}
			node.e = e;
		}
	}
	
	//����ĳһ��ֵ�����ص�һ���±�
	public int search(Object e){
		if(head.next==null){
			System.out.println("����Ϊ��");
			return -1;
		}else{
			Node node = head;
			for (int i = 0; i < size; i++) {
				node = node.next;
				if(node.e==e){
					return i;
				}
			}
		}
		return -1;
	}
	
}
