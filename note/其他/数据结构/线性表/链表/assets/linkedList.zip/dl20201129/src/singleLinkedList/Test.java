package singleLinkedList;

public class Test {

	public static void main(String[] args) {
		Boolean i1 = false;
        Boolean i2 = false;
        Boolean i3 = true;
        Boolean i4 = true;

         
        System.out.println(i1==i2);
        System.out.println(i3==i4);
	}

}
