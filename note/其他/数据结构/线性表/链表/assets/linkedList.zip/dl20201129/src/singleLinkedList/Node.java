package singleLinkedList;

public class Node {
	public Object e;
	public Node next;

	public Node() {

	}

	public Node(Object e) {
		this.e = e;
		next = null;
	}
}
